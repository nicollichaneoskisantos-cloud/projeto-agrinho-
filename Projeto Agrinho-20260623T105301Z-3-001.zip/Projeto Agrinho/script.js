document.getElementById('btn-calcular').addEventListener('click', function() {
    // Pegar os valores dos inputs
    const area = parseFloat(document.getElementById('area').value);
    const manejo = document.getElementById('manejo').value;
    const insumos = document.getElementById('insumos').value;

    // Validação simples
    if (!area || area <= 0 || !manejo || !insumos) {
        alert('Por favor, preencha todos os campos corretamente.');
        return;
    }

    // Variáveis base para cálculo simulado
    let fatorCarbono = 0; // kg de CO2 por hectare/ano
    let saudeSolo = "";
    let recomendacao = "";

    // Lógica do Impacto do Manejo
    if (manejo === "convencional") {
        fatorCarbono += 1200;
        saudeSolo = "Crítica (Erosão/Exaustão)";
    } else if (manejo === "direto") {
        fatorCarbono += 400;
        saudeSolo = "Boa (Boa retenção de carbono e água)";
    } else if (manejo === "organico") {
        fatorCarbono += 100;
        saudeSolo = "Excelente (Solo vivo e regenerativo)";
    }

    // Lógica do Impacto dos Insumos
    if (insumos === "quimico") {
        fatorCarbono += 800;
    } else if (insumos === "misto") {
        fatorCarbono += 300;
    } else if (insumos === "biologico") {
        fatorCarbono -= 200; // Captura/mitigação de emissões
    }

    // Cálculo final baseado na área informada
    let carbonoTotal = fatorCarbono * area;
    if (carbonoTotal < 0) carbonoTotal = 0; // Evitar carbono negativo bizarro para o usuário

    // Definindo as dicas/recomendações dinamicamente
    if (manejo === "convencional" || insumos === "quimico") {
        recomendacao = "Seu sistema atual possui altas emissões. Experimente migrar gradativamente para o Plantio Direto e introduzir bioinsumos. Isso reduz gastos com combustível, protege o solo contra a seca e diminui sua pegada de carbono.";
    } else if (manejo === "direto" && insumos === "misto") {
        recomendacao = "Ótimo trabalho! Você já adota boas práticas. O próximo passo rumo ao futuro sustentável é tentar aumentar a porcentagem de defensores biológicos e planejar a rotação de culturas para enriquecer o solo naturalmente.";
    } else {
        recomendacao = "Excelente! Sua propriedade é um modelo de sustentabilidade. O manejo biológico e orgânico protege a biodiversidade local e garante a segurança alimentar do futuro. Continue promovendo essas práticas na sua comunidade!";
    }

    // Atualizar a interface do usuário (DOM)
    document.getElementById('carbono-texto').innerText = `${carbonoTotal.toLocaleString('pt-BR')} kg de CO₂/ano`;
    document.getElementById('solo-texto').innerText = saudeSolo;
    document.getElementById('recomendacao-texto').innerText = recomendacao;

    // Mostrar a caixa de resultados removendo a classe 'hidden'
    document.getElementById('resultado').classList.remove('hidden');

    // Rolagem suave até o resultado
    document.getElementById('resultado').scrollIntoView({ behavior: 'smooth' });
});